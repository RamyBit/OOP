﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KartenMeschen
{
    class Karte
    {
        public string Wert { get; set; }
        public string Farbe { get; set; }
    }
}
